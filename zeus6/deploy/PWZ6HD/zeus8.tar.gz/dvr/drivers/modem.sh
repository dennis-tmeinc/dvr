#!/bin/sh

insmod /mnt/nand/dvr/drivers/usbserial.ko
#insmod /mnt/nand/dvr/drivers/ftdi_sio.ko vendor=0x0403 product=0x6015
