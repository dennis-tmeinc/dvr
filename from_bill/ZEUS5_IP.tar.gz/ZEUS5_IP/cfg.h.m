
/* generic definition file */

// option to enable ioprocess display mcu debugging message
// #define MCU_DEBUG  (1)

// to enable dvrsvr network message
// #define NETDBG

// to enable power cycling test firmware
// #define POWERCYCLETEST

