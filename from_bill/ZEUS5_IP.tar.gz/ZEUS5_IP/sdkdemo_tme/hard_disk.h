#ifndef	__HARD_DISK_H__
#define	__HARD_DISK_H__
extern int  netSwitchHdMode(int netfd,char * cmd,int clientAddr);
#endif
